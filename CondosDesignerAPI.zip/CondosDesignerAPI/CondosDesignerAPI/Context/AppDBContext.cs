﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CondosDesignerAPI.Model
{
    public partial class AppDBContext : DbContext
    {
        public AppDBContext()
        {
        }

        public AppDBContext(DbContextOptions<AppDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AreaLavado> AreaLavado { get; set; }
        public virtual DbSet<AreasLavadoXpiso> AreasLavadoXpiso { get; set; }
        public virtual DbSet<Arquitecto> Arquitecto { get; set; }
        public virtual DbSet<Balcon> Balcon { get; set; }
        public virtual DbSet<BalconesXpiso> BalconesXpiso { get; set; }
        public virtual DbSet<Banio> Banio { get; set; }
        public virtual DbSet<BaniosXpiso> BaniosXpiso { get; set; }
        public virtual DbSet<Bbqarea> Bbqarea { get; set; }
        public virtual DbSet<BbqareaXpiso> BbqareaXpiso { get; set; }
        public virtual DbSet<Bodega> Bodega { get; set; }
        public virtual DbSet<BodegasXpiso> BodegasXpiso { get; set; }
        public virtual DbSet<Cochera> Cochera { get; set; }
        public virtual DbSet<CocherasXpiso> CocherasXpiso { get; set; }
        public virtual DbSet<Cocina> Cocina { get; set; }
        public virtual DbSet<CocinaXpiso> CocinaXpiso { get; set; }
        public virtual DbSet<Comedor> Comedor { get; set; }
        public virtual DbSet<ComedorXpiso> ComedorXpiso { get; set; }
        public virtual DbSet<Dormitorio> Dormitorio { get; set; }
        public virtual DbSet<DormitoriosXpiso> DormitoriosXpiso { get; set; }
        public virtual DbSet<Escalera> Escalera { get; set; }
        public virtual DbSet<EscalerasXpiso> EscalerasXpiso { get; set; }
        public virtual DbSet<Id> Id { get; set; }
        public virtual DbSet<Oficina> Oficina { get; set; }
        public virtual DbSet<OficinasXpiso> OficinasXpiso { get; set; }
        public virtual DbSet<Piso> Piso { get; set; }
        public virtual DbSet<PisosXvivienda> PisosXvivienda { get; set; }
        public virtual DbSet<Sala> Sala { get; set; }
        public virtual DbSet<SalaXpiso> SalaXpiso { get; set; }
        public virtual DbSet<Terraza> Terraza { get; set; }
        public virtual DbSet<TerrazasXpiso> TerrazasXpiso { get; set; }
        public virtual DbSet<Vivienda> Vivienda { get; set; }
        public virtual DbSet<WalkingCloset> WalkingCloset { get; set; }
        public virtual DbSet<WalkingClosetXpiso> WalkingClosetXpiso { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AreaLavado>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<AreasLavadoXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idlavado })
                    .HasName("PK__AreasLav__528F4368CE7091F5");

                entity.HasOne(d => d.IdlavadoNavigation)
                    .WithMany(p => p.AreasLavadoXpiso)
                    .HasForeignKey(d => d.Idlavado)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AreasLava__IDLav__2EDAF651");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.AreasLavadoXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AreasLava__IDPis__2DE6D218");
            });

            modelBuilder.Entity<Arquitecto>(entity =>
            {
                entity.HasNoKey();

                entity.HasIndex(e => e.Usuario)
                    .HasName("UQ__Arquitec__9AFF8FC6AC8E9EF5")
                    .IsUnique();

                entity.Property(e => e.Apellido1).IsUnicode(false);

                entity.Property(e => e.Apellido2).IsUnicode(false);

                entity.Property(e => e.Contrasenia).IsUnicode(false);

                entity.Property(e => e.Nivel).IsUnicode(false);

                entity.Property(e => e.Nombre).IsUnicode(false);

                entity.Property(e => e.Usuario).IsUnicode(false);
            });

            modelBuilder.Entity<Balcon>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<BalconesXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idbalcon })
                    .HasName("PK__Balcones__D98E528F7A572D2A");

                entity.HasOne(d => d.IdbalconNavigation)
                    .WithMany(p => p.BalconesXpiso)
                    .HasForeignKey(d => d.Idbalcon)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BalconesX__IDBal__3493CFA7");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.BalconesXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BalconesX__IDPis__339FAB6E");
            });

            modelBuilder.Entity<Banio>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);

                entity.Property(e => e.Tipo).IsUnicode(false);
            });

            modelBuilder.Entity<BaniosXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idbanio })
                    .HasName("PK__BaniosXP__2FD4EAABE1142079");

                entity.HasOne(d => d.IdbanioNavigation)
                    .WithMany(p => p.BaniosXpiso)
                    .HasForeignKey(d => d.Idbanio)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BaniosXPi__IDBan__6EF57B66");

                entity.HasOne(d => d.IddormitorioNavigation)
                    .WithMany(p => p.BaniosXpiso)
                    .HasForeignKey(d => d.Iddormitorio)
                    .HasConstraintName("FK__BaniosXPi__IDDor__6FE99F9F");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.BaniosXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BaniosXPi__IDPis__6E01572D");
            });

            modelBuilder.Entity<Bbqarea>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<BbqareaXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idbbq })
                    .HasName("PK__BBQAreaX__957A2E4F743EA2E4");

                entity.HasOne(d => d.IdbbqNavigation)
                    .WithMany(p => p.BbqareaXpiso)
                    .HasForeignKey(d => d.Idbbq)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BBQAreaXP__IDBBQ__123EB7A3");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.BbqareaXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BBQAreaXP__IDPis__114A936A");
            });

            modelBuilder.Entity<Bodega>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<BodegasXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idbodega })
                    .HasName("PK__BodegasX__21DC8F472DA52EAF");

                entity.HasOne(d => d.IdbodegaNavigation)
                    .WithMany(p => p.BodegasXpiso)
                    .HasForeignKey(d => d.Idbodega)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BodegasXP__IDBod__236943A5");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.BodegasXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BodegasXP__IDPis__22751F6C");
            });

            modelBuilder.Entity<Cochera>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<CocherasXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idcochera })
                    .HasName("PK__Cocheras__63EE2A3027A123FC");

                entity.HasOne(d => d.IdcocheraNavigation)
                    .WithMany(p => p.CocherasXpiso)
                    .HasForeignKey(d => d.Idcochera)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CocherasX__IDCoc__17F790F9");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.CocherasXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CocherasX__IDPis__17036CC0");
            });

            modelBuilder.Entity<Cocina>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<CocinaXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idcocina })
                    .HasName("PK__CocinaXP__79C16C2195E64B82");

                entity.HasOne(d => d.IdcocinaNavigation)
                    .WithMany(p => p.CocinaXpiso)
                    .HasForeignKey(d => d.Idcocina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CocinaXPi__IDCoc__75A278F5");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.CocinaXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CocinaXPi__IDPis__74AE54BC");
            });

            modelBuilder.Entity<Comedor>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<ComedorXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idcomedor })
                    .HasName("PK__ComedorX__70CFFA0F99F546A3");

                entity.HasOne(d => d.IdcomedorNavigation)
                    .WithMany(p => p.ComedorXpiso)
                    .HasForeignKey(d => d.Idcomedor)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ComedorXP__IDCom__01142BA1");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.ComedorXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ComedorXP__IDPis__00200768");
            });

            modelBuilder.Entity<Dormitorio>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<DormitoriosXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Iddormitorio })
                    .HasName("PK__Dormitor__C93FE563D818A14D");

                entity.HasOne(d => d.IddormitorioNavigation)
                    .WithMany(p => p.DormitoriosXpiso)
                    .HasForeignKey(d => d.Iddormitorio)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Dormitori__IDDor__693CA210");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.DormitoriosXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Dormitori__IDPis__68487DD7");
            });

            modelBuilder.Entity<Escalera>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);

                entity.Property(e => e.Tipo).IsUnicode(false);
            });

            modelBuilder.Entity<EscalerasXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idescalera })
                    .HasName("PK__Escalera__3479A0F41B5A6EF6");

                entity.HasOne(d => d.IdescaleraNavigation)
                    .WithMany(p => p.EscalerasXpiso)
                    .HasForeignKey(d => d.Idescalera)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Escaleras__IDEsc__06CD04F7");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.EscalerasXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Escaleras__IDPis__05D8E0BE");
            });

            modelBuilder.Entity<Id>(entity =>
            {
                entity.HasKey(e => e.Id1)
                    .HasName("PK__ID__3214EC270365E044");

                entity.Property(e => e.Id1).ValueGeneratedNever();
            });

            modelBuilder.Entity<Oficina>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<OficinasXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idoficina })
                    .HasName("PK__Oficinas__E2E1DDA8F0A01A22");

                entity.HasOne(d => d.IdoficinaNavigation)
                    .WithMany(p => p.OficinasXpiso)
                    .HasForeignKey(d => d.Idoficina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__OficinasX__IDOfi__1DB06A4F");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.OficinasXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__OficinasX__IDPis__1CBC4616");
            });

            modelBuilder.Entity<Piso>(entity =>
            {
                entity.HasIndex(e => e.Identificador)
                    .HasName("UQ__Piso__C83612B06B3000E4")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<PisosXvivienda>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idvivienda })
                    .HasName("PK__PisosXVi__DD3769F0E95CD193");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.PisosXvivienda)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PisosXViv__IDPis__628FA481");

                entity.HasOne(d => d.IdviviendaNavigation)
                    .WithMany(p => p.PisosXvivienda)
                    .HasForeignKey(d => d.Idvivienda)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PisosXViv__IDViv__6383C8BA");
            });

            modelBuilder.Entity<Sala>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<SalaXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idsala })
                    .HasName("PK__SalaXPis__6023674B0E5DE0D7");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.SalaXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SalaXPiso__IDPis__7A672E12");

                entity.HasOne(d => d.IdsalaNavigation)
                    .WithMany(p => p.SalaXpiso)
                    .HasForeignKey(d => d.Idsala)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SalaXPiso__IDSal__7B5B524B");
            });

            modelBuilder.Entity<Terraza>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<TerrazasXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idterraza })
                    .HasName("PK__Terrazas__A8DF9A579F01E300");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.TerrazasXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__TerrazasX__IDPis__0B91BA14");

                entity.HasOne(d => d.IdterrazaNavigation)
                    .WithMany(p => p.TerrazasXpiso)
                    .HasForeignKey(d => d.Idterraza)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__TerrazasX__IDTer__0C85DE4D");
            });

            modelBuilder.Entity<Vivienda>(entity =>
            {
                entity.HasIndex(e => e.Identificador)
                    .HasName("UQ__Vivienda__C83612B02B60BA1D")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);

                entity.Property(e => e.TipoAgua).IsUnicode(false);

            });

            modelBuilder.Entity<WalkingCloset>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Identificador).IsUnicode(false);
            });

            modelBuilder.Entity<WalkingClosetXpiso>(entity =>
            {
                entity.HasKey(e => new { e.Idpiso, e.Idwc })
                    .HasName("PK__WalkingC__A7CBBAAB74D418B0");

                entity.HasOne(d => d.IdpisoNavigation)
                    .WithMany(p => p.WalkingClosetXpiso)
                    .HasForeignKey(d => d.Idpiso)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__WalkingCl__IDPis__282DF8C2");

                entity.HasOne(d => d.IdwcNavigation)
                    .WithMany(p => p.WalkingClosetXpiso)
                    .HasForeignKey(d => d.Idwc)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__WalkingClo__IDWC__29221CFB");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
