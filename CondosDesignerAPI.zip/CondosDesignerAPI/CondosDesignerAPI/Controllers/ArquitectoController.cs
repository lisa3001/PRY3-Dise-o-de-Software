﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CondosDesignerAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CondosDesignerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArquitectoController : ControllerBase
    {
        private readonly AppDBContext context;

        public ArquitectoController(AppDBContext context)
        {
            this.context = context;
        }

        //Arquitecto
        //-----------------------------------------------------------------
        // POST api/<controller>/arquitecto
        [HttpPost("arquitecto")]
        public ActionResult Post([FromBody] Arquitecto arquitecto)
        {
            try
            {
                context.Arquitecto.Add(arquitecto);
                context.SaveChanges();
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        // GET: api/<controller>/arquitecto
        [HttpGet("arquitecto")]
        public IEnumerable<Arquitecto> Get()
        {
            return context.Arquitecto.ToList();
        }

        // GET api/<controller>/arquitecto/id
        [HttpGet("arquitecto/{id}")]
        public Arquitecto Get(string id)
        {
            var arquitecto = context.Arquitecto.FirstOrDefault(p => p.Usuario == id);
            return arquitecto;
        }

        // PUT api/<controller>/arquitecto/id
        [HttpPut("arquitecto/{id}")]
        public ActionResult Put(string id, [FromBody] Arquitecto arquitecto)
        {
            if (arquitecto.Usuario == id)
            {
                context.Entry(arquitecto).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                context.SaveChanges();
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        // DELETE api/<controller>/arquitecto/id
        [HttpDelete("arquitecto/{id}")]
        public ActionResult Delete(string id)
        {
            var arqui = context.Arquitecto.FirstOrDefault(p => p.Usuario == id);
            if (arqui != null)
            {
                context.Remove(arqui);
                context.SaveChanges();
                return Ok();
            }
            else
            {
                return BadRequest();

            }
        }

    }
}
