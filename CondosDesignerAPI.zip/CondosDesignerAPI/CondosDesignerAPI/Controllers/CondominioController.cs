﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CondosDesignerAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CondosDesignerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CondominioController : ControllerBase
    {

        private readonly AppDBContext context;

        public CondominioController(AppDBContext context)
        {
            this.context = context;
        }

        //Condominio
        //-----------------------------------------------------------------
        // POST api/<controller>/condomino
        [HttpPost("condominio")]
        public ActionResult Post([FromBody] Condominio condo)
        {
            try
            {
                //context.Condominio.Add(condo);
                context.SaveChanges();
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        // GET: api/<controller>/condominio
        [HttpGet("condominio")]
        public IEnumerable<Arquitecto> Get()
        {
            return context.Arquitecto.ToList();
        }

        // GET api/<controller>/condominio/id
        [HttpGet("condominio/{id}")]
        public Arquitecto Get(string id)
        {
            var arquitecto = context.Arquitecto.FirstOrDefault(p => p.Usuario == id);
            return arquitecto;
        }

        // PUT api/<controller>/condominio/id
        [HttpPut("condominio/{id}")]
        public ActionResult Put(string id, [FromBody] Condominio condo)
        {
            if (condo.Usuario == id)
            {
                context.Entry(condo).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                context.SaveChanges();
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        // DELETE api/<controller>/condominio/id
        [HttpDelete("condominio/{id}")]
        public ActionResult Delete(string id)
        {
            var condo = context.Arquitecto.FirstOrDefault(p => p.Usuario == id);
            if (condo != null)
            {
                context.Remove(condo);
                context.SaveChanges();
                return Ok();
            }
            else
            {
                return BadRequest();

            }
        }

    }
}
