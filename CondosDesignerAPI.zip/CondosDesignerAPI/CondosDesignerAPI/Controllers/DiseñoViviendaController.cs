﻿using System;
using System.Collections.Generic;
using System.Linq;
using CondosDesignerAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CondosDesingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DiseñoViviendaController : ControllerBase
    {
        private readonly AppDBContext context;


        public DiseñoViviendaController(AppDBContext context)
        {
            this.context = context;
        }

        //Vivienda
        //-----------------------------------------------------------------
        // POST api/<controller>/vivienda
        [HttpPost("vivienda")]
        public ActionResult Post([FromBody] Vivienda vivienda)
        {
            try
            {
                int idVivienda = SetId("Vivienda");
                vivienda.Id = idVivienda;
                if (vivienda.Identificador.Trim().Equals(""))
                {
                    vivienda.Identificador = "Vivienda " + idVivienda.ToString();
                }
                context.Vivienda.Add(vivienda);
                context.SaveChanges();
                ActualizarID(idVivienda, "Vivienda");
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Vivienda
        // GET: api/<controller>/vivienda
        [HttpGet("vivienda")]
        public IEnumerable<Vivienda> Get()
        {
            return context.Vivienda.Include(x => x.PisosXvivienda).ToList();
        }



        //Piso
        //-----------------------------------------------------------------
        // POST api/<controller>/piso/identificadorVivienda
        [HttpPost("piso/{idVivienda}")]
        public ActionResult Post([FromBody] Piso piso, [FromRoute] string idVivienda)
        {
            try
            {
                int id = SetId("Piso");
                piso.Id = id;
                if (piso.Identificador.Trim().Equals(""))
                {
                    piso.Identificador = "Piso " + id.ToString();
                }
                context.Piso.Add(piso);
                context.SaveChanges();
                ActualizarID(id, "Piso");
                InsertarPisoXVivienda(idVivienda, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar piso a vivienda
        //--------------------------------------
        public void InsertarPisoXVivienda(string identificadorVivienda, int idPiso)
        {
            PisosXvivienda pisoXVivienda = new PisosXvivienda();
            int idVivienda = context.Vivienda.FirstOrDefault(x => x.Identificador == identificadorVivienda).Id;
            pisoXVivienda.Idvivienda = idVivienda;
            pisoXVivienda.Idpiso = idPiso;
            context.PisosXvivienda.Add(pisoXVivienda);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Piso
        // GET: api/<controller>/piso
        [HttpGet("piso")]
        public IEnumerable<Piso> GetPisos()
        {
            return context.Piso.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/piso/idPiso
        [HttpGet("piso/{id}")]
        public Piso Get(int id)
        {
            var piso = context.Piso.Include(x => x.AreasLavadoXpiso)
                                    .Include(x => x.BalconesXpiso)
                                    .Include(x => x.BaniosXpiso)
                                    .Include(x => x.BbqareaXpiso)
                                    .Include(x => x.BodegasXpiso)
                                    .Include(x => x.CocherasXpiso)
                                    .Include(x => x.CocinaXpiso)
                                    .Include(x => x.ComedorXpiso)
                                    .Include(x => x.DormitoriosXpiso)
                                    .Include(x => x.EscalerasXpiso)
                                    .Include(x => x.OficinasXpiso)
                                    .Include(x => x.PisosXvivienda)
                                    .Include(x => x.SalaXpiso)
                                    .Include(x => x.TerrazasXpiso)
                                    .Include(x => x.WalkingClosetXpiso)
                                    .FirstOrDefault(p => p.Id == id);
            return piso;
        }

        //Dormitorio
        //-----------------------------------------------------------------
        // POST api/<controller>/dormitorio/identificadorPiso
        [HttpPost("dormitorio/{idPiso}")]
        public ActionResult Post([FromBody] Dormitorio dormitorio, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Dormitorio");
                dormitorio.Id = id;
                if (dormitorio.Identificador.Trim().Equals(""))
                {
                    dormitorio.Identificador = "Dormitorio " + id.ToString();
                }
                context.Dormitorio.Add(dormitorio);
                context.SaveChanges();
                ActualizarID(id, "Dormitorio");
                InsertarDormitorioXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar dormitorio a piso
        //--------------------------------------
        public void InsertarDormitorioXPiso(string identificadorPiso, int idDormitorio)
        {
            DormitoriosXpiso dormitorioXPiso = new DormitoriosXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            dormitorioXPiso.Iddormitorio = idDormitorio;
            dormitorioXPiso.Idpiso = idPiso;
            context.DormitoriosXpiso.Add(dormitorioXPiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Dormitorio
        // GET: api/<controller>/dormitorio
        [HttpGet("dormitorio")]
        public IEnumerable<Dormitorio> GetDormitorios()
        {
            return context.Dormitorio.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/dormitorio/idDormitorio
        [HttpGet("dormitorio/{id}")]
        public Dormitorio GetDormitorio(int id)
        {
            var dormitorio = context.Dormitorio.FirstOrDefault(p => p.Id == id);
            return dormitorio;
        }

        //Baño
        //-----------------------------------------------------------------
        // POST api/<controller>/banio/identificadorPiso
        [HttpPost("banio/{idPiso}")]
        public ActionResult Post([FromBody] BanioPrevio banioPrevio, [FromRoute] string idPiso)
        {
            try
            {
                Banio banio = new Banio();
                int id = SetId("Banio");
                banio.Id = id;
                banio.Identificador = banioPrevio.Identificador;
                if (banio.Identificador.Trim().Equals(""))
                {
                    banio.Identificador = "Baño " + id.ToString();
                }
                banio.Tipo = banioPrevio.Tipo;
                banio.Longitud = banioPrevio.Longitud;
                banio.Anchura = banioPrevio.Anchura;
                context.Banio.Add(banio);
                context.SaveChanges();
                ActualizarID(id, "Banio");
                InsertarBanioXPiso(idPiso, id, banioPrevio.identificadorDormitorio);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar baño a piso
        //--------------------------------------
        public void InsertarBanioXPiso(string identificadorPiso, int idbanio, string identificadorDormitorio)
        {
            BaniosXpiso baniosXpiso = new BaniosXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            baniosXpiso.Idpiso = idPiso;
            baniosXpiso.Idbanio = idbanio;
            if (identificadorDormitorio != "")
            {
              Dormitorio dormitorio = context.Dormitorio.FirstOrDefault(x => x.Identificador == identificadorDormitorio);
                if (dormitorio != null) baniosXpiso.Iddormitorio = dormitorio.Id; 
            }
            context.BaniosXpiso.Add(baniosXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Baños
        // GET: api/<controller>/banio
        [HttpGet("banio")]
        public IEnumerable<Banio> GetBanios()
        {
            return context.Banio.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/banio/idBanios
        [HttpGet("banio/{id}")]
        public Banio GetBanio(int id)
        {
            var json = context.Banio.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //Cocina
        //-----------------------------------------------------------------
        // POST api/<controller>/cocina/identificadorPiso
        [HttpPost("cocina/{idPiso}")]
        public ActionResult Post([FromBody] Cocina cocina, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Cocina");
                cocina.Id = id;
                if (cocina.Identificador.Trim().Equals(""))
                {
                    cocina.Identificador = "Cocina " + id.ToString();
                }
                context.Cocina.Add(cocina);
                context.SaveChanges();
                ActualizarID(id, "Cocina");
                InsertarCocinaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar cocina a piso
        //--------------------------------------
        public void InsertarCocinaXPiso(string identificadorPiso, int idCocina)
        {
            CocinaXpiso cocinaXpiso = new CocinaXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            cocinaXpiso.Idcocina = idCocina;
            cocinaXpiso.Idpiso = idPiso;
            context.CocinaXpiso.Add(cocinaXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //cocina
        // GET: api/<controller>/cocina
        [HttpGet("cocina")]
        public IEnumerable<Cocina> GetCocinas()
        {
            return context.Cocina.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/cocina/idCocina
        [HttpGet("cocina/{id}")]
        public Cocina GetCocina(int id)
        {
            var json = context.Cocina.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //Sala
        //-----------------------------------------------------------------
        // POST api/<controller>/sala/identificadorPiso
        [HttpPost("sala/{idPiso}")]
        public ActionResult Post([FromBody] Sala sala, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Sala");
                sala.Id = id;
                if (sala.Identificador.Trim().Equals(""))
                {
                    sala.Identificador = "Sala " + id.ToString();
                }
                context.Sala.Add(sala);
                context.SaveChanges();
                ActualizarID(id, "Sala");
                InsertarSalaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar sala a piso
        //--------------------------------------
        public void InsertarSalaXPiso(string identificadorPiso, int idSala)
        {
            SalaXpiso salaXpiso = new SalaXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            salaXpiso.Idsala = idSala;
            salaXpiso.Idpiso = idPiso;
            context.SalaXpiso.Add(salaXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Sala
        // GET: api/<controller>/sala
        [HttpGet("sala")]
        public IEnumerable<Sala> GetSalas()
        {
            return context.Sala.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/sala/idSala
        [HttpGet("sala/{id}")]
        public Sala GetSala(int id)
        {
            var json = context.Sala.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //Comedor
        //-----------------------------------------------------------------
        // POST api/<controller>/comedor/identificadorPiso
        [HttpPost("comedor/{idPiso}")]
        public ActionResult Post([FromBody] Comedor comedor, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Comedor");
                comedor.Id = id;
                if (comedor.Identificador.Trim().Equals(""))
                {
                    comedor.Identificador = "Comedor " + id.ToString();
                }
                context.Comedor.Add(comedor);
                context.SaveChanges();
                ActualizarID(id, "Comedor");
                InsertarComedorXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar comedor a piso
        //--------------------------------------
        public void InsertarComedorXPiso(string identificadorPiso, int idComedor)
        {
            ComedorXpiso comedorXpiso = new ComedorXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            comedorXpiso.Idcomedor = idComedor;
            comedorXpiso.Idpiso = idPiso;
            context.ComedorXpiso.Add(comedorXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Comedor
        // GET: api/<controller>/comedor
        [HttpGet("comedor")]
        public IEnumerable<Comedor> GetComedores()
        {
            return context.Comedor.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/comedor/idComedor
        [HttpGet("comedor/{id}")]
        public Comedor GetComedor(int id)
        {
            var json = context.Comedor.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //Escalera
        //-----------------------------------------------------------------
        // POST api/<controller>/escalera/identificadorPiso
        [HttpPost("escalera/{idPiso}")]
        public ActionResult Post([FromBody] Escalera escalera, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Escalera");
                escalera.Id = id;
                if (escalera.Identificador.Trim().Equals(""))
                {
                    escalera.Identificador = "Escalera " + id.ToString();
                }
                context.Escalera.Add(escalera);
                context.SaveChanges();
                ActualizarID(id, "Escalera");
                InsertarEscaleraXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar escalera a piso
        //--------------------------------------
        public void InsertarEscaleraXPiso(string identificadorPiso, int idEscalera)
        {
            EscalerasXpiso escalerasXpiso = new EscalerasXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            escalerasXpiso.Idescalera = idEscalera;
            escalerasXpiso.Idpiso = idPiso;
            context.EscalerasXpiso.Add(escalerasXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Escalera
        // GET: api/<controller>/escalera
        [HttpGet("escalera")]
        public IEnumerable<Escalera> GetEscalera()
        {
            return context.Escalera.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/escalera/id
        [HttpGet("escalera/{id}")]
        public Escalera GetEscalera(int id)
        {
            var json = context.Escalera.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //Terraza
        //-----------------------------------------------------------------
        // POST api/<controller>/terraza/identificadorPiso
        [HttpPost("terraza/{idPiso}")]
        public ActionResult Post([FromBody] Terraza terraza, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Terraza");
                terraza.Id = id;
                if (terraza.Identificador.Trim().Equals(""))
                {
                    terraza.Identificador = "Terraza " + id.ToString();
                }
                context.Terraza.Add(terraza);
                context.SaveChanges();
                ActualizarID(id, "Terraza");
                InsertarTerrazaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar Terraza a piso
        //--------------------------------------
        public void InsertarTerrazaXPiso(string identificadorPiso, int idTerraza)
        {
            TerrazasXpiso terrazasXpiso = new TerrazasXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            terrazasXpiso.Idterraza = idTerraza;
            terrazasXpiso.Idpiso = idPiso;
            context.TerrazasXpiso.Add(terrazasXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Terraza
        // GET: api/<controller>/terraza
        [HttpGet("terraza")]
        public IEnumerable<Terraza> GetTerrazas()
        {
            return context.Terraza.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/terraza/id
        [HttpGet("terraza/{id}")]
        public Terraza GetTerraza(int id)
        {
            var json = context.Terraza.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //BBQArea
        //-----------------------------------------------------------------
        // POST api/<controller>/bbqarea/identificadorPiso
        [HttpPost("bbqarea/{idPiso}")]
        public ActionResult Post([FromBody] Bbqarea bbqarea, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("BBQ");
                bbqarea.Id = id;
                if (bbqarea.Identificador.Trim().Equals(""))
                {
                    bbqarea.Identificador = "Área BBQ " + id.ToString();
                }
                context.Bbqarea.Add(bbqarea);
                context.SaveChanges();
                ActualizarID(id, "BBQ");
                InsertarBBQAreaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar BBQArea a piso
        //--------------------------------------
        public void InsertarBBQAreaXPiso(string identificadorPiso, int idBbq)
        {
            BbqareaXpiso bbqareaXpiso = new BbqareaXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            bbqareaXpiso.Idbbq = idBbq;
            bbqareaXpiso.Idpiso = idPiso;
            context.BbqareaXpiso.Add(bbqareaXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //BBQArea
        // GET: api/<controller>/bbqarea
        [HttpGet("bbqarea")]
        public IEnumerable<Bbqarea> GetBbqArea()
        {
            return context.Bbqarea.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/bbqarea/id
        [HttpGet("bbqarea/{id}")]
        public Bbqarea GetBbqArea(int id)
        {
            var json = context.Bbqarea.FirstOrDefault(p => p.Id == id);
            return json;
        }

        //Cochera
        //-----------------------------------------------------------------
        // POST api/<controller>/cochera/identificadorPiso
        [HttpPost("cochera/{idPiso}")]
        public ActionResult Post([FromBody] Cochera cochera, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Cochera");
                cochera.Id = id;
                if (cochera.Identificador.Trim().Equals(""))
                {
                    cochera.Identificador = "Cochera " + id.ToString();
                }
                context.Cochera.Add(cochera);
                context.SaveChanges();
                ActualizarID(id, "Cochera");
                InsertarCocheraXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar cochera a piso
        //--------------------------------------
        public void InsertarCocheraXPiso(string identificadorPiso, int idCochera)
        {
            CocherasXpiso cocherasXpiso = new CocherasXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            cocherasXpiso.Idcochera = idCochera;
            cocherasXpiso.Idpiso = idPiso;
            context.CocherasXpiso.Add(cocherasXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Cochera
        // GET: api/<controller>/cochera
        [HttpGet("cochera")]
        public IEnumerable<Cochera> GetCocheras()
        {
            return context.Cochera.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/cochera/id
        [HttpGet("cochera/{id}")]
        public Cochera GetCochera(int id)
        {
            var json = context.Cochera.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //Oficina
        //-----------------------------------------------------------------
        // POST api/<controller>/oficina/identificadorPiso
        [HttpPost("oficina/{idPiso}")]
        public ActionResult Post([FromBody] Oficina oficina, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Oficina");
                oficina.Id = id;
                if (oficina.Identificador.Trim().Equals(""))
                {
                    oficina.Identificador = "Oficina " + id.ToString();
                }
                context.Oficina.Add(oficina);
                context.SaveChanges();
                ActualizarID(id, "Oficina");
                InsertarOficinaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar oficina a piso
        //--------------------------------------
        public void InsertarOficinaXPiso(string identificadorPiso, int idOficina)
        {
            OficinasXpiso oficinasXpiso = new OficinasXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            oficinasXpiso.Idoficina = idOficina;
            oficinasXpiso.Idpiso = idPiso;
            context.OficinasXpiso.Add(oficinasXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Oficina
        // GET: api/<controller>/oficina
        [HttpGet("oficina")]
        public IEnumerable<Oficina> GetOficinas()
        {
            return context.Oficina.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/oficina/id
        [HttpGet("oficina/{id}")]
        public Oficina GetOficina(int id)
        {
            var json = context.Oficina.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //Bodega
        //-----------------------------------------------------------------
        // POST api/<controller>/bodega/identificadorPiso
        [HttpPost("bodega/{idPiso}")]
        public ActionResult Post([FromBody] Bodega bodega, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Bodega");
                bodega.Id = id;
                if (bodega.Identificador.Trim().Equals(""))
                {
                    bodega.Identificador = "Bodega " + id.ToString();
                }
                context.Bodega.Add(bodega);
                context.SaveChanges();
                ActualizarID(id, "Bodega");
                InsertarBodegaXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar bodega a un piso
        //--------------------------------------
        public void InsertarBodegaXPiso(string identificadorPiso, int idBodega)
        {
            BodegasXpiso bodegasXpiso = new BodegasXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            bodegasXpiso.Idbodega = idBodega;
            bodegasXpiso.Idpiso = idPiso;
            context.BodegasXpiso.Add(bodegasXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Bodega
        // GET: api/<controller>/bodega
        [HttpGet("bodega")]
        public IEnumerable<Bodega> GetBodegas()
        {
            return context.Bodega.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/bodeg/id
        [HttpGet("bodega/{id}")]
        public Bodega GetBodega(int id)
        {
            var json = context.Bodega.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //WalkingCloset
        //-----------------------------------------------------------------
        // POST api/<controller>/walkingcloset/identificadorPiso
        [HttpPost("walkingcloset/{idPiso}")]
        public ActionResult Post([FromBody] WalkingCloset wc, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("WC");
                wc.Id = id;
                if (wc.Identificador.Trim().Equals(""))
                {
                    wc.Identificador = "Walking Closet " + id.ToString();
                }
                context.WalkingCloset.Add(wc);
                context.SaveChanges();
                ActualizarID(id, "WC");
                InsertarWalkingClosetXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar walking closet a un piso
        //--------------------------------------
        public void InsertarWalkingClosetXPiso(string identificadorPiso, int idWc)
        {
            WalkingClosetXpiso walkingClosetXpiso = new WalkingClosetXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            walkingClosetXpiso.Idwc = idWc;
            walkingClosetXpiso.Idpiso = idPiso;
            context.WalkingClosetXpiso.Add(walkingClosetXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Walking Closet
        // GET: api/<controller>/walkingcloset
        [HttpGet("walkingcloset")]
        public IEnumerable<WalkingCloset> GetWalkingClosets()
        {
            return context.WalkingCloset.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/walkingcloset/id
        [HttpGet("walkingcloset/{id}")]
        public WalkingCloset GetWalkingCloset(int id)
        {
            var json = context.WalkingCloset.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //AreaLavado
        //-----------------------------------------------------------------
        // POST api/<controller>/arealavado/identificadorPiso
        [HttpPost("arealavado/{idPiso}")]
        public ActionResult Post([FromBody] AreaLavado al, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("AL");
                al.Id = id;
                if (al.Identificador.Trim().Equals(""))
                {
                    al.Identificador = "Área Lavado " + id.ToString();
                }
                context.AreaLavado.Add(al);
                context.SaveChanges();
                ActualizarID(id, "AL");
                InsertarAreaLavadoXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar un area de lavado a un piso
        //--------------------------------------
        public void InsertarAreaLavadoXPiso(string identificadorPiso, int idAl)
        {
            AreasLavadoXpiso areasLavadoXpiso = new AreasLavadoXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            areasLavadoXpiso.Idlavado = idAl;
            areasLavadoXpiso.Idpiso = idPiso;
            context.AreasLavadoXpiso.Add(areasLavadoXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Area Lavado
        // GET: api/<controller>/arealavado
        [HttpGet("arealavado")]
        public IEnumerable<AreaLavado> GetAreasLavado()
        {
            return context.AreaLavado.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/arealavado/id
        [HttpGet("arealavado/{id}")]
        public AreaLavado GetAreaLavado(int id)
        {
            var json = context.AreaLavado.FirstOrDefault(p => p.Id == id);
            return json;
        }


        //Balcón
        //-----------------------------------------------------------------
        // POST api/<controller>/balcon/identificadorPiso
        [HttpPost("balcon/{idPiso}")]
        public ActionResult Post([FromBody] Balcon balcon, [FromRoute] string idPiso)
        {
            try
            {
                int id = SetId("Balcon");
                balcon.Id = id;
                if (balcon.Identificador.Trim().Equals(""))
                {
                    balcon.Identificador = "Balcón " + id.ToString();
                }
                context.Balcon.Add(balcon);
                context.SaveChanges();
                ActualizarID(id, "Balcon");
                InsertarBalconXPiso(idPiso, id);
                return Ok(); //Retorna código 200
            }
            catch (Exception exception)
            {
                return BadRequest(exception); //Retorna código 400
            }
        }

        //Agregar un balcón a un piso
        //--------------------------------------
        public void InsertarBalconXPiso(string identificadorPiso, int idBalcon)
        {
            BalconesXpiso balconesXpiso = new BalconesXpiso();
            int idPiso = context.Piso.FirstOrDefault(x => x.Identificador == identificadorPiso).Id;
            balconesXpiso.Idbalcon = idBalcon;
            balconesXpiso.Idpiso = idPiso;
            context.BalconesXpiso.Add(balconesXpiso);
            context.SaveChanges();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        //Balcon
        // GET: api/<controller>/balcon
        [HttpGet("balcon")]
        public IEnumerable<Balcon> GetBalcones()
        {
            return context.Balcon.ToList();
        }

        //-----------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------
        // GET api/<controller>/balcon/id
        [HttpGet("balcon/{id}")]
        public Balcon GetBalcon(int id)
        {
            var json = context.Balcon.FirstOrDefault(p => p.Id == id);
            return json;
        }



        //Tabla de IDs
        //------------------------------------------------------------------------
        public int SetId(string tipo)
        {
            int cantidad = 0;
            var tablaIds = context.Id.FirstOrDefault(p => p.Id1 == 1);
            if (tipo == "Vivienda") cantidad = (int)tablaIds.CantidadViviendas;
            else if (tipo == "Piso") cantidad = (int)tablaIds.CantidadPisos;
            else if (tipo == "Dormitorio") cantidad = (int)tablaIds.CantidadDormitorios;
            else if (tipo == "Banio") cantidad = (int)tablaIds.CantidadBanios;
            else if (tipo == "Cocina") cantidad = (int)tablaIds.CantidadCocinas;
            else if (tipo == "Sala") cantidad = (int)tablaIds.CantidadSalas;
            else if (tipo == "Comedor") cantidad = (int)tablaIds.CantidadComedores;
            else if (tipo == "Escalera") cantidad = (int)tablaIds.CantidadEscaleras;
            else if (tipo == "Terraza") cantidad = (int)tablaIds.CantidadTerrazas;
            else if (tipo == "BBQ") cantidad = (int)tablaIds.CantidadBbqs;
            else if (tipo == "Cochera") cantidad = (int)tablaIds.CantidadCocheras;
            else if (tipo == "Oficina") cantidad = (int)tablaIds.CantidadOficinas;
            else if (tipo == "Bodega") cantidad = (int)tablaIds.CantidadBodegas;
            else if (tipo == "WC") cantidad = (int)tablaIds.CantidadWcs;
            else if (tipo == "AL") cantidad = (int)tablaIds.CantidadAreasLavado;
            else if (tipo == "Balcon") cantidad = (int)tablaIds.CantidadBalcon;
            else if (tipo == "Arquitecto") cantidad = (int)tablaIds.CantidadArquitectos;
            return cantidad + 1;
        }

        public void ActualizarID(int nuevo, string tipo)
        {
            Id tablaIds = context.Id.FirstOrDefault(p => p.Id1 == 1); 

            if (tipo == "Vivienda") tablaIds.CantidadViviendas = nuevo;
            else if (tipo == "Piso") tablaIds.CantidadPisos = nuevo;
            else if (tipo == "Dormitorio") tablaIds.CantidadDormitorios = nuevo;
            else if (tipo == "Banio") tablaIds.CantidadBanios = nuevo;
            else if (tipo == "Cocina") tablaIds.CantidadCocinas = nuevo;
            else if (tipo == "Sala") tablaIds.CantidadSalas = nuevo;
            else if (tipo == "Comedor") tablaIds.CantidadComedores = nuevo;
            else if (tipo == "Escalera") tablaIds.CantidadEscaleras = nuevo;
            else if (tipo == "Terraza") tablaIds.CantidadTerrazas = nuevo;
            else if (tipo == "BBQ") tablaIds.CantidadBbqs = nuevo;
            else if (tipo == "Cochera") tablaIds.CantidadCocheras = nuevo;
            else if (tipo == "Oficina") tablaIds.CantidadOficinas = nuevo;
            else if (tipo == "Bodega") tablaIds.CantidadBodegas = nuevo;
            else if (tipo == "WC") tablaIds.CantidadWcs = nuevo;
            else if (tipo == "AL") tablaIds.CantidadAreasLavado = nuevo;
            else if (tipo == "Balcon") tablaIds.CantidadBalcon = nuevo;
            else if (tipo == "Arquitecto") tablaIds.CantidadArquitectos = nuevo;

            context.Entry(tablaIds).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
        }

    }
}
