﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("AreasLavadoXPiso")]
    public partial class AreasLavadoXpiso
    {
        [Key]
        [Column("IDLavado")]
        public int Idlavado { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idlavado))]
        [InverseProperty(nameof(AreaLavado.AreasLavadoXpiso))]
        [JsonIgnore]
        public virtual AreaLavado IdlavadoNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.AreasLavadoXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
