﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Arquitecto
    {
        [Required]
        [Column("nombre")]
        [StringLength(50)]
        public string Nombre { get; set; }
        [Required]
        [Column("apellido1")]
        [StringLength(50)]
        public string Apellido1 { get; set; }
        [Required]
        [Column("apellido2")]
        [StringLength(50)]
        public string Apellido2 { get; set; }
        [Column("aniosExperiencia")]
        public int AniosExperiencia { get; set; }
        [Required]
        [Column("nivel")]
        [StringLength(50)]
        public string Nivel { get; set; }
        [Required]
        [Column("usuario")]
        [StringLength(50)]
        public string Usuario { get; set; }
        [Required]
        [Column("contrasenia")]
        [StringLength(30)]
        public string Contrasenia { get; set; }
    }
}
