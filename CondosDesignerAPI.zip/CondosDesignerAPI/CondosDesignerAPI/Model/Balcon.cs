﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Balcon
    {
        public Balcon()
        {
            BalconesXpiso = new HashSet<BalconesXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("logitud")]
        public int Logitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdbalconNavigation")]
        [JsonIgnore]
        public virtual ICollection<BalconesXpiso> BalconesXpiso { get; set; }
    }
}
