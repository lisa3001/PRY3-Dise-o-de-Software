﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("BalconesXPiso")]
    public partial class BalconesXpiso
    {
        [Key]
        [Column("IDBalcon")]
        public int Idbalcon { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }
        [Column("IDHabitacion")]
        public int Idhabitacion { get; set; }

        [ForeignKey(nameof(Idbalcon))]
        [InverseProperty(nameof(Balcon.BalconesXpiso))]
        [JsonIgnore]
        public virtual Balcon IdbalconNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.BalconesXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
