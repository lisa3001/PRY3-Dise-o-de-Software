﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CondosDesignerAPI.Model
{
    public class BanioPrevio
    {
        public int Id { get; set; }
        public string Identificador { get; set; }
        public string Tipo { get; set; }
        public int Longitud { get; set; }
        public int Anchura { get; set; }

        public string identificadorDormitorio { get; set; }

    }
}
