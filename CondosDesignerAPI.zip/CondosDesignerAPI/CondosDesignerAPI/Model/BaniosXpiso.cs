﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("BaniosXPiso")]
    public partial class BaniosXpiso
    {
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }
        [Key]
        [Column("IDBanio")]
        public int Idbanio { get; set; }
        [Column("IDDormitorio")]
        public int? Iddormitorio { get; set; }

        [ForeignKey(nameof(Idbanio))]
        [InverseProperty(nameof(Banio.BaniosXpiso))]
        [JsonIgnore]
        public virtual Banio IdbanioNavigation { get; set; }
        [ForeignKey(nameof(Iddormitorio))]
        [InverseProperty(nameof(Dormitorio.BaniosXpiso))]
        public virtual Dormitorio IddormitorioNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.BaniosXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
