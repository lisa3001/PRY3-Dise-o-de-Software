﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("BBQArea")]
    public partial class Bbqarea
    {
        public Bbqarea()
        {
            BbqareaXpiso = new HashSet<BbqareaXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("logitud")]
        public int Logitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdbbqNavigation")]
        [JsonIgnore]
        public virtual ICollection<BbqareaXpiso> BbqareaXpiso { get; set; }
    }
}
