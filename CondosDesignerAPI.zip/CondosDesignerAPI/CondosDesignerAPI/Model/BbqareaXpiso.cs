﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("BBQAreaXPiso")]
    public partial class BbqareaXpiso
    {
        [Key]
        [Column("IDBBQ")]
        public int Idbbq { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idbbq))]
        [InverseProperty(nameof(Bbqarea.BbqareaXpiso))]
        [JsonIgnore]
        public virtual Bbqarea IdbbqNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.BbqareaXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
