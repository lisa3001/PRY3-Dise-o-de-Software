﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("BodegasXPiso")]
    public partial class BodegasXpiso
    {
        [Key]
        [Column("IDBodega")]
        public int Idbodega { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idbodega))]
        [InverseProperty(nameof(Bodega.BodegasXpiso))]
        [JsonIgnore]
        public virtual Bodega IdbodegaNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.BodegasXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
