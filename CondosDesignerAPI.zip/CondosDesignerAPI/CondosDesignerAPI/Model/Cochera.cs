﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Cochera
    {
        public Cochera()
        {
            CocherasXpiso = new HashSet<CocherasXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("logitud")]
        public int Logitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdcocheraNavigation")]
        [JsonIgnore]
        public virtual ICollection<CocherasXpiso> CocherasXpiso { get; set; }
    }
}
