﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("CocherasXPiso")]
    public partial class CocherasXpiso
    {
        [Key]
        [Column("IDCochera")]
        public int Idcochera { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idcochera))]
        [InverseProperty(nameof(Cochera.CocherasXpiso))]
        [JsonIgnore]
        public virtual Cochera IdcocheraNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.CocherasXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
