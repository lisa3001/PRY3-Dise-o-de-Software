﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("CocinaXPiso")]
    public partial class CocinaXpiso
    {
        [Key]
        [Column("IDCocina")]
        public int Idcocina { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idcocina))]
        [InverseProperty(nameof(Cocina.CocinaXpiso))]
        [JsonIgnore]
        public virtual Cocina IdcocinaNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.CocinaXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
