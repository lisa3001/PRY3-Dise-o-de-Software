﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("ComedorXPiso")]
    public partial class ComedorXpiso
    {
        [Key]
        [Column("IDComedor")]
        public int Idcomedor { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idcomedor))]
        [InverseProperty(nameof(Comedor.ComedorXpiso))]
        [JsonIgnore]
        public virtual Comedor IdcomedorNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.ComedorXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
