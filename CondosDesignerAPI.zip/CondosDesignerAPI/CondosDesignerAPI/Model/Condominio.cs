﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CondosDesignerAPI.Model
{
    public class Condominio
    {
        public string Usuario { get; set; }
    }
}
