﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("DormitoriosXPiso")]
    public partial class DormitoriosXpiso
    {
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }
        [Key]
        [Column("IDDormitorio")]
        public int Iddormitorio { get; set; }

        [ForeignKey(nameof(Iddormitorio))]
        [InverseProperty(nameof(Dormitorio.DormitoriosXpiso))]
        [JsonIgnore]
        public virtual Dormitorio IddormitorioNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.DormitoriosXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
