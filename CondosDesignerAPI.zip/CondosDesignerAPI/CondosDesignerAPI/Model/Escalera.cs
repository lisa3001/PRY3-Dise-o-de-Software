﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Escalera
    {
        public Escalera()
        {
            EscalerasXpiso = new HashSet<EscalerasXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Required]
        [Column("tipo")]
        [StringLength(50)]
        public string Tipo { get; set; }
        [Column("longitud")]
        public int Longitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdescaleraNavigation")]
        [JsonIgnore]
        public virtual ICollection<EscalerasXpiso> EscalerasXpiso { get; set; }
    }
}
