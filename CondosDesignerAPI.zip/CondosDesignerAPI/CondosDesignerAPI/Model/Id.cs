﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("ID")]
    public partial class Id
    {
        [Key]
        [Column("ID")]
        public int Id1 { get; set; }
        [Column("cantidadViviendas")]
        public int CantidadViviendas { get; set; }
        [Column("cantidadPisos")]
        public int CantidadPisos { get; set; }
        [Column("cantidadDormitorios")]
        public int CantidadDormitorios { get; set; }
        [Column("cantidadBanios")]
        public int CantidadBanios { get; set; }
        [Column("cantidadCocinas")]
        public int CantidadCocinas { get; set; }
        [Column("cantidadSalas")]
        public int CantidadSalas { get; set; }
        [Column("cantidadComedores")]
        public int CantidadComedores { get; set; }
        [Column("cantidadEscaleras")]
        public int CantidadEscaleras { get; set; }
        [Column("cantidadTerrazas")]
        public int CantidadTerrazas { get; set; }
        [Column("cantidadBBQs")]
        public int CantidadBbqs { get; set; }
        [Column("cantidadCocheras")]
        public int CantidadCocheras { get; set; }
        [Column("cantidadOficinas")]
        public int CantidadOficinas { get; set; }
        [Column("cantidadBodegas")]
        public int CantidadBodegas { get; set; }
        [Column("cantidadWCs")]
        public int CantidadWcs { get; set; }
        [Column("cantidadAreasLavado")]
        public int CantidadAreasLavado { get; set; }
        [Column("cantidadBalcon")]
        public int CantidadBalcon { get; set; }
        [Column("cantidadArquitectos")]
        public int CantidadArquitectos { get; set; }
    }
}
