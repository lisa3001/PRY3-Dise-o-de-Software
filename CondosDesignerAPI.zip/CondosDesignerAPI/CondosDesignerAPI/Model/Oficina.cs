﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Oficina
    {
        public Oficina()
        {
            OficinasXpiso = new HashSet<OficinasXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("logitud")]
        public int Logitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdoficinaNavigation")]
        [JsonIgnore]
        public virtual ICollection<OficinasXpiso> OficinasXpiso { get; set; }
    }
}
