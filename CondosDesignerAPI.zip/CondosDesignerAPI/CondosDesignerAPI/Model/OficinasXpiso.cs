﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("OficinasXPiso")]
    public partial class OficinasXpiso
    {
        [Key]
        [Column("IDOficina")]
        public int Idoficina { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idoficina))]
        [InverseProperty(nameof(Oficina.OficinasXpiso))]
        [JsonIgnore]
        public virtual Oficina IdoficinaNavigation { get; set; }
        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.OficinasXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
    }
}
