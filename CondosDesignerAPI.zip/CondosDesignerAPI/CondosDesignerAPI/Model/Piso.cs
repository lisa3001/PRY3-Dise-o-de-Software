﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Piso
    {
        public Piso()
        {
            AreasLavadoXpiso = new HashSet<AreasLavadoXpiso>();
            BalconesXpiso = new HashSet<BalconesXpiso>();
            BaniosXpiso = new HashSet<BaniosXpiso>();
            BbqareaXpiso = new HashSet<BbqareaXpiso>();
            BodegasXpiso = new HashSet<BodegasXpiso>();
            CocherasXpiso = new HashSet<CocherasXpiso>();
            CocinaXpiso = new HashSet<CocinaXpiso>();
            ComedorXpiso = new HashSet<ComedorXpiso>();
            DormitoriosXpiso = new HashSet<DormitoriosXpiso>();
            EscalerasXpiso = new HashSet<EscalerasXpiso>();
            OficinasXpiso = new HashSet<OficinasXpiso>();
            PisosXvivienda = new HashSet<PisosXvivienda>();
            SalaXpiso = new HashSet<SalaXpiso>();
            TerrazasXpiso = new HashSet<TerrazasXpiso>();
            WalkingClosetXpiso = new HashSet<WalkingClosetXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("longitud")]
        public int Longitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<AreasLavadoXpiso> AreasLavadoXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<BalconesXpiso> BalconesXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<BaniosXpiso> BaniosXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<BbqareaXpiso> BbqareaXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<BodegasXpiso> BodegasXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<CocherasXpiso> CocherasXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<CocinaXpiso> CocinaXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<ComedorXpiso> ComedorXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<DormitoriosXpiso> DormitoriosXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<EscalerasXpiso> EscalerasXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<OficinasXpiso> OficinasXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<PisosXvivienda> PisosXvivienda { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<SalaXpiso> SalaXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<TerrazasXpiso> TerrazasXpiso { get; set; }
        [InverseProperty("IdpisoNavigation")]
        public virtual ICollection<WalkingClosetXpiso> WalkingClosetXpiso { get; set; }
    }
}
