﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("PisosXVivienda")]
    public partial class PisosXvivienda
    {
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }
        [Key]
        [Column("IDVivienda")]
        public int Idvivienda { get; set; }

        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.PisosXvivienda))]
        
        public virtual Piso IdpisoNavigation { get; set; }
        [ForeignKey(nameof(Idvivienda))]
        [InverseProperty(nameof(Vivienda.PisosXvivienda))]
        [JsonIgnore]
        public virtual Vivienda IdviviendaNavigation { get; set; }
    }
}
