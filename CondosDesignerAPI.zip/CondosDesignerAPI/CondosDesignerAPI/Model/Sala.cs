﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Sala
    {
        public Sala()
        {
            SalaXpiso = new HashSet<SalaXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("longitud")]
        public int Longitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdsalaNavigation")]
        [JsonIgnore]
        public virtual ICollection<SalaXpiso> SalaXpiso { get; set; }
    }
}
