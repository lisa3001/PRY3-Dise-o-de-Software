﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("SalaXPiso")]
    public partial class SalaXpiso
    {
        [Key]
        [Column("IDSala")]
        public int Idsala { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.SalaXpiso))]
        
        public virtual Piso IdpisoNavigation { get; set; }
        [ForeignKey(nameof(Idsala))]
        [InverseProperty(nameof(Sala.SalaXpiso))]
        [JsonIgnore]
        public virtual Sala IdsalaNavigation { get; set; }
    }
}
