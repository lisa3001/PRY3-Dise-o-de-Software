﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace CondosDesignerAPI.Model
{
    public partial class Terraza
    {
        public Terraza()
        {
            TerrazasXpiso = new HashSet<TerrazasXpiso>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Column("longitud")]
        public int Longitud { get; set; }
        [Column("anchura")]
        public int Anchura { get; set; }

        [InverseProperty("IdterrazaNavigation")]
        [JsonIgnore]
        public virtual ICollection<TerrazasXpiso> TerrazasXpiso { get; set; }
    }
}
