﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("TerrazasXPiso")]
    public partial class TerrazasXpiso
    {
        [Key]
        [Column("IDTerraza")]
        public int Idterraza { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.TerrazasXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
        [ForeignKey(nameof(Idterraza))]
        [InverseProperty(nameof(Terraza.TerrazasXpiso))]
        [JsonIgnore]
        public virtual Terraza IdterrazaNavigation { get; set; }
    }
}
