﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    public partial class Vivienda
    {
        public Vivienda()
        {
            PisosXvivienda = new HashSet<PisosXvivienda>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [Column("identificador")]
        [StringLength(100)]
        public string Identificador { get; set; }
        [Required]
        [Column("tipoAgua")]
        [StringLength(30)]
        public string TipoAgua { get; set; }
        [Column("cantidadPisos")]
        public int? CantidadPisos { get; set; }
        [Column("areaTerreno")]
        public int AreaTerreno { get; set; }

        [InverseProperty("IdviviendaNavigation")]
        public virtual ICollection<PisosXvivienda> PisosXvivienda { get; set; }
    }
}
