﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CondosDesignerAPI.Model
{
    [Table("WalkingClosetXPiso")]
    public partial class WalkingClosetXpiso
    {
        [Key]
        [Column("IDWC")]
        public int Idwc { get; set; }
        [Key]
        [Column("IDPiso")]
        public int Idpiso { get; set; }

        [ForeignKey(nameof(Idpiso))]
        [InverseProperty(nameof(Piso.WalkingClosetXpiso))]
        public virtual Piso IdpisoNavigation { get; set; }
        [ForeignKey(nameof(Idwc))]
        [InverseProperty(nameof(WalkingCloset.WalkingClosetXpiso))]
        [JsonIgnore]
        public virtual WalkingCloset IdwcNavigation { get; set; }
    }
}
